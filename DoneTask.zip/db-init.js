var firebaseConfig = {
    apiKey: "AIzaSyDNcS6kR2jguwH4J4sYrBVW9atnaH7Xy3w",
    authDomain: "shoeshelf-d4e0b.firebaseapp.com",
    projectId: "shoeshelf-d4e0b",
    storageBucket: "shoeshelf-d4e0b.appspot.com",
    messagingSenderId: "806303829392",
    appId: "1:806303829392:web:8722e4bc0e9c288079b715",
    measurementId: "G-RN8280L7TE"
  };
  // Initialize Firebase
firebase.initializeApp(firebaseConfig);
  
